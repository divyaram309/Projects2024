package config;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

import static io.appium.java_client.remote.AndroidMobileCapabilityType.*;

public class AppiumConfig {
    private static AndroidDriver<AndroidElement> driver;

    public static AndroidDriver<AndroidElement> setUp() throws MalformedURLException {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "13");
        caps.setCapability(MobileCapabilityType.UDID, "PNXKOV4PIJFIZXAA");
        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "OnePlus Nord2 5G");
        caps.setCapability(MobileCapabilityType.APP, "com.openai.chatgpt");
        caps.setCapability("appPackage", "com.openai.chatgpt");
        caps.setCapability("appActivity", "com.openai.chatgpt.LoginActivity");
        caps.setCapability(MobileCapabilityType.NO_RESET, true);

        // Initialize AndroidDriver<AndroidElement> directly
        try {
            driver = new AndroidDriver<>(new URL("http://localhost:4723/wd/hub"), caps);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return driver;
    }

    @Test
    public void testCal() throws Exception {
        //locate the Text on the calculator by using By.name()
//        WebElement two = driver.findElement(By.name("2"));
//        two.click();
//        WebElement plus = driver.findElement(By.name("+"));
//        plus.click();
//        WebElement four = driver.findElement(By.name("4"));
//        four.click();
//        WebElement equalTo = driver.findElement(By.name("="));
//        equalTo.click();
//        //locate the edit box of the calculator by using By.tagName()
//        WebElement results = driver.findElement(By.tagName("EditText"));
//        //Check the calculated value on the edit box
//        assert results.getText().equals("6") : "Actual value is : " + results.getText() + " did not match with expected value: 6";
//
//    }
//
//    @AfterClass
//    public void teardown() {
//        //close the app
//        driver.quit();
//    }
//}
    }
}
