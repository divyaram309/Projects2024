package pages;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    private AndroidDriver<AndroidElement> driver;

    public LoginPage(AndroidDriver<AndroidElement> driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public AndroidElement getUsernameField() {
        return driver.findElementById("//input[@id='email-input']");
    }

    public AndroidElement getPasswordField() {
        return driver.findElementById("//input[@id='password']");
    }

    public AndroidElement getLoginButton() {
        return driver.findElementById("//button[normalize-space()='Continue']");
    }

    public AndroidElement getHomeScreen() {
        return driver.findElementById("//div[@class='flex h-full flex-col items-center justify-center text-token-text-primary']");
    }
}
