package steps;

import config.AppiumConfig;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import pages.LoginPage;

public class LoginSteps {
    private AndroidDriver<AndroidElement> driver;
    private LoginPage loginPage;

    @Given("^I am on the login screen$")
    public void iAmOnTheLoginScreen() throws Exception {
        driver = AppiumConfig.setUp();
        loginPage = new LoginPage(driver);
    }

    @When("^I enter valid credentials$")
    public void iEnterValidCredentials() {
        loginPage.getUsernameField().sendKeys("divyaram309@gmail.com");
        loginPage.getPasswordField().sendKeys("Hetvik@828");
        loginPage.getLoginButton().click();
    }

    @Then("^I should see the home screen$")
    public void iShouldSeeTheHomeScreen() {
        Assert.assertTrue(loginPage.getHomeScreen().isDisplayed());
    }
}
