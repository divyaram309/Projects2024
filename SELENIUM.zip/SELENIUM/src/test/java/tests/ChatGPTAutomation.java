package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import pages.ChatGPTPage;

import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class ChatGPTAutomation {
    WebDriver driver;
    ChatGPTPage chatGPTPage;

    // Define the base URL as a constant
    private static final String BASE_URL = "https://www.chatgpt.com";

    @BeforeClass
    @Parameters("browser")
    public void setUp(@Optional("chrome") String browser) {
        System.out.println("Browser is: " + browser);
        // Initialize the WebDriver based on the browser parameter
        switch (browser.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                driver = new ChromeDriver();
                break;
            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
            case "edge":
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
            case "safari":
                WebDriverManager.safaridriver().setup();
                driver = new SafariDriver();
                break;
            default:
                throw new IllegalArgumentException("Browser " + browser + " not supported");
        }

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        chatGPTPage = new ChatGPTPage(driver);
    }

    @Test(priority = 2)
    public void testChatGPT() {
        // Navigate to ChatGPT's website
        driver.get(BASE_URL);

        // Interact with the page using Page Object methods
        chatGPTPage.enterMessage("Explain Selenium automation");
        chatGPTPage.clickSendButton();
        chatGPTPage.assertChatResponse();
    }

    @Test(priority = 1)
    public void signup() {
        // Navigate to ChatGPT's website
//        driver.get("https://auth.openai.com/authorize?client_id=TdJIcbe16WoTHtN95nyywh5E4yOo6ItG&scope=openid%20email%20profile%20offline_access%20model.request%20model.read%20organization.read%20organization.write&response_type=code&redirect_uri=https%3A%2F%2Fchatgpt.com%2Fapi%2Fauth%2Fcallback%2Flogin-web&audience=https%3A%2F%2Fapi.openai.com%2Fv1&device_id=b0c127cd-4834-4c45-b386-49203d5a0bae&prompt=login&screen_hint=signup&ext-statsig-tier=production&ext-oai-did=b0c127cd-4834-4c45-b386-49203d5a0bae&flow=control&state=YDHAlM5vGKgGQcMvY70WltjhR9owgQkcLRiM5DErLvQ&code_challenge=GzYdgAq4ysx0hqfGb_ArU1Azms1BlvOb_uWxWgvornA&code_challenge_method=S256");

        driver.get(BASE_URL);

        Set<String> windowHandles = driver.getWindowHandles();
        String mainWindowHandle = driver.getWindowHandle();
        System.out.println("windowHandles:" + windowHandles);
        System.out.println("mainWindowHandle :" + mainWindowHandle);

        for (String handle : windowHandles) {
            driver.switchTo().window(handle);
            chatGPTPage.clickSignup();
//            chatGPTPage.visibilityOfDashB();
            chatGPTPage.clickenterEmail();
            chatGPTPage.Continue(driver).click();
            chatGPTPage.pwd();
            chatGPTPage.Continue1();
        }
//        chatGPTPage.clickSignup();

        // Wait and switch to the desired frame if necessary
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("5bb77cf04a49da835fa98e6796e79354")));

//        chatGPTPage.visibilityOfDashB();
//        chatGPTPage.clickenterEmail();
//        chatGPTPage.Continue(driver).click();
//        chatGPTPage.pwd();
//        chatGPTPage.Continue1();
        // Navigate to the second URL
        driver.get(BASE_URL);
    }


    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
