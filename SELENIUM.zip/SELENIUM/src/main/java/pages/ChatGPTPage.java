package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class ChatGPTPage {
    WebDriver driver;
    WebDriverWait wait;

    // Constructor
    public ChatGPTPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Timeout in seconds
    }

    // Locators
    By chatInput = By.xpath("//textarea[@id='prompt-textarea']"); // Replace with actual ID or selector
    By sendButton = By.xpath("(//*[name()='svg'][@class='icon-2xl'])[1]"); // Replace with actual ID or selector
    By Login = By.xpath("//div[normalize-space()='Log in']");
    By Signup = By.xpath("//div[normalize-space()='Sign up']");
    By pwd = By.xpath("//input[@id='//']"); // Replace with actual ID or selector for the password field
    By enterEmail = By.xpath("//input[@id='email-input']");

    By createActDashBoard = By.xpath("//section[@class='content-wrapper']");
    @FindBy(xpath = "//button[normalize-space()='Continue']")
    WebElement Continue;

    By Continue1 = By.xpath("(//button[normalize-space()='Continue'])[1]");

    public WebElement Continue(WebDriver driver) {
        return Continue;
    }

    // Methods
    public void enterMessage(String message) {
        WebElement inputField = driver.findElement(chatInput);
        inputField.sendKeys(message);

        // Initialize Actions class
        Actions actions = new Actions(driver);

        // Send Enter key using Actions
        actions.sendKeys(inputField, Keys.ENTER).perform(); // or use "\uE007" for Unicode
    }

    public void enterLogin() {
        WebElement loginElement = driver.findElement(Login);
        loginElement.click();
    }

    public void clickSendButton() {
        driver.findElement(sendButton).click();
    }

    public void visibilityOfDashB() {
        WebElement dashboardElement = wait.until(ExpectedConditions.visibilityOfElementLocated(createActDashBoard));

        // Assert that the element is displayed
        Assert.assertTrue(dashboardElement.isDisplayed(), "Dashboard element is not visible.");
    }

    public void clickSignup() {
        driver.findElement(Signup).click();

    }

    public void pwd() {
        driver.findElement(pwd).sendKeys("Divyaram@820");
    }

    public void clickenterEmail() {

        driver.findElement(enterEmail).sendKeys("divyaram309@gmail.com");


    }

    public void Continue1() {
        driver.findElement(Continue1).click();
    }

    public void assertChatResponse() {
        // Wait for the response element to be visible
        WebElement responseElement = wait.until(ExpectedConditions.visibilityOfElementLocated(sendButton));

        // Retrieve the actual response text from the web element
        String actualResponse = responseElement.getText();

        // Assert that the actual response matches the expected response
        Assert.assertEquals(actualResponse, "Chat response did not match expected response.");
    }
}
